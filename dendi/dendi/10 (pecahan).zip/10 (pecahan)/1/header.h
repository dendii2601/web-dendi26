#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int pembilang;
    int penyebut;
}pecahan;

#endif // HEADER_H_INCLUDED
