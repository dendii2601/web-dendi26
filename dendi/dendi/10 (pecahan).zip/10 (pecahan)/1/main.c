#include "header.h"

int main()
{
    printf("no 1=");
    printPecahan(makePecahan(1,4));
    printf("\n");
    printf("no 2=");
    printPecahan(makePecahan(2,5));
    printf("\n");
    printf("penjumlahan\n");
    printPecahan(makePecahan(1,4));
    printf(" + ");
    printPecahan(makePecahan(2,5));
    printf(" = ");
    printPecahan(addPecahan(makePecahan(1,4),makePecahan(2,5)));
    printf("\n");
    printf("pengurangan\n");
    printPecahan(makePecahan(1,4));
    printf(" - ");
    printPecahan(makePecahan(2,5));
    printf(" = ");
    printPecahan(subPecahan(makePecahan(1,4),makePecahan(2,5)));
    printf("\n");
    printf("pengalian\n");
    printPecahan(makePecahan(1,4));
    printf(" * ");
    printPecahan(makePecahan(2,5));
    printf(" = ");
    printPecahan(mulPecahan(makePecahan(1,4),makePecahan(2,5)));
    printf("\n");
    printf("pembagian\n");
    printPecahan(makePecahan(1,4));
    printf(" / ");
    printPecahan(makePecahan(2,5));
    printf(" = ");
    printPecahan(divPecahan(makePecahan(1,4),makePecahan(2,5)));
    printf("\n");
    printf("desimal\n");
    printf("desimal = %.f\n",desimalPecahan(makePecahan(1,4)));
    printf("perbandingan samadengan\n");
    printPecahan(makePecahan(1,4));
    printf(" = ");
    printPecahan(makePecahan(2,5));
    printf(" ? %d\n",isEqual(makePecahan(1,4),makePecahan(2,5)));
    printf("perbandingan lebih besar\n");
    printPecahan(makePecahan(1,4));
    printf(" > ");
    printPecahan(makePecahan(2,5));
    printf(" ? %d\n",isBigger(makePecahan(1,4),makePecahan(2,5)));
    printf("perbandingan lebih kecil\n");
    printPecahan(makePecahan(1,4));
    printf(" < ");
    printPecahan(makePecahan(2,5));
    printf(" ? %d\n",isSmaller(makePecahan(1,4),makePecahan(2,5)));
    return 0;
}
