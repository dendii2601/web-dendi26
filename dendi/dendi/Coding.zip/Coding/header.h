#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>

int x, y;
void swapp(int data[], int i, int j);
void selectionSort1(int data[], int i, int n);
void selectionSort2(int data[], int i, int n);
void cetak(int *arrData, int ukuran);
void totalHarga(int *hasil, int num1, int num2);

#endif // HEADER_H_INCLUDED
