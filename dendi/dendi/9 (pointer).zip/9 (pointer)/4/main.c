#include "header.h"

int main()
{
    int ar1[]={1,2,3,4,5};
    int ar2[]={11,12,13,14,15};
    printArray(ar1, 5);
    printf("\n");
    printArray(ar2, 5);
    printf("\n");

    return 0;
}
