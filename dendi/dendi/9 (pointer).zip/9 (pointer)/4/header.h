#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>

void printArray(int *arrData, int size);

#endif // HEADER_H_INCLUDED
