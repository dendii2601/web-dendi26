#include "header.h"

void initDynArray(int *arrData, int size)
{
    if(size==0)
    {

    }
    else
    {
        arrData[size]=size;
        initDynArray(arrData, size-1);
        printf(" %d ", arrData[size]);
    }

}
