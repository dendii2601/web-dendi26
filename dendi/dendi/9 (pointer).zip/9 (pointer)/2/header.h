#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>

void changeValue(int *target, int num1, int num2);

#endif // HEADER_H_INCLUDED
