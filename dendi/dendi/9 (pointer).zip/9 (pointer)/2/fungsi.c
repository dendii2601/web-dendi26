#include "header.h"

void changeValue(int *target, int num1, int num2)
{
    *target=num1+num2;
}
